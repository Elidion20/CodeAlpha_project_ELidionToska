function getDOB() {
    // Get the values from the input fields
    const dobInput = document.getElementById('inputDob').value;
    const currentDateInput = document.getElementById('cdate').value;

    // Validate if both dates are provided
    if (!dobInput || !currentDateInput) {
        document.getElementById('errorMessage').textContent = 'Please enter both Date of Birth and Current Date.';
        return;
    }

    // Convert input values to Date objects
    const dob = new Date(dobInput);
    const currentDate = new Date(currentDateInput);

    // Check for valid dates
    if (isNaN(dob) || isNaN(currentDate)) {
        document.getElementById('errorMessage').textContent = 'Please enter valid dates.';
        return;
    }

    // Calculate age in years, months, and days
    let ageYears = currentDate.getFullYear() - dob.getFullYear();
    let ageMonths = currentDate.getMonth() - dob.getMonth();
    let ageDays = currentDate.getDate() - dob.getDate();

    // Adjust if the birthday hasn't occurred yet this year
    if (ageDays < 0) {
        ageMonths--;
        const lastMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0); // Last day of the previous month
        ageDays += lastMonth.getDate();
    }

    if (ageMonths < 0) {
        ageYears--;
        ageMonths += 12;
    }

    // Display the result
    document.getElementById('currentAge').textContent = `Your age is ${ageYears} years, ${ageMonths} months, and ${ageDays} days.`;
    document.getElementById('errorMessage').textContent = ''; // Clear error message if calculation is successful
}

